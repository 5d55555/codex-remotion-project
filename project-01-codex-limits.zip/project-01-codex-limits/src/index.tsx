import {registerRoot} from 'remotion';
import {Composition} from 'remotion';
import {CodexLimits} from './CodexLimits';

registerRoot(() => (
  <Composition
    id="CodexLimits"
    component={CodexLimits}
    durationInFrames={30 * 30}
    fps={30}
    width={1080}
    height={1408}
  />
));
