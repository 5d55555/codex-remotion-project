import React from 'react';
import {AbsoluteFill, interpolate, spring, useCurrentFrame, useVideoConfig} from 'remotion';

const C = {bg: '#171717', panel: '#202020', line: '#373737', text: '#f1f1f1', muted: '#9b9b9b', blue: '#9ecbff', red: '#ff6f6f'};

function Icon({children}: {children: React.ReactNode}) { return <span style={{display: 'inline-flex', width: 28, justifyContent: 'center', color: C.muted}}>{children}</span>; }

export const CodexLimits: React.FC = () => {
  const frame = useCurrentFrame();
  const {fps} = useVideoConfig();
  const t = frame / fps;
  const typed = t >= 2.2;
  const sent = t >= 5.1;
  const thinking = t >= 5.6;
  const menu = t >= 0.6 && t < 2.0;
  const ultra = t >= 2.0;
  const fast = t >= 3.1;
  const prompt = typed ? '你好' : '';
  const fiveHour = sent ? Math.max(0, interpolate(t, [5.8, 16.5], [100, 0], {extrapolateLeft: 'clamp', extrapolateRight: 'clamp'})) : 100;
  const sevenDay = sent ? interpolate(t, [5.8, 16.5], [100, 85], {extrapolateLeft: 'clamp', extrapolateRight: 'clamp'}) : 100;
  const pulse = thinking ? 0.65 + Math.sin(frame / 5) * 0.22 : 1;
  const entrance = spring({frame, fps, config: {damping: 18, stiffness: 80}});

  return <AbsoluteFill style={{backgroundColor: C.bg, color: C.text, fontFamily: 'Inter, -apple-system, BlinkMacSystemFont, "Noto Sans SC", sans-serif'}}>
    <div style={{position: 'absolute', inset: 0, opacity: interpolate(entrance, [0, 1], [0, 1])}}>
      <div style={{position: 'absolute', top: 0, left: 0, right: 0, height: 2, background: '#292929'}} />
      <div style={{position: 'absolute', left: 62, right: 62, bottom: 468}}>
        {menu && <div style={{position: 'absolute', bottom: 172, left: 90, width: 620, border: `1px solid ${C.line}`, borderRadius: 18, background: '#242424', boxShadow: '0 20px 70px #0008', padding: 18, zIndex: 3}}>
          {['gpt 6 astra', 'gpt 6 nova', 'gpt 5.6 terra'].map((name, i) => <div key={name} style={{padding: '18px 20px', borderRadius: 10, background: i === 0 ? '#343434' : 'transparent', fontSize: 25, display: 'flex', justifyContent: 'space-between'}}><span>{name}</span>{i === 0 && <span style={{color: C.blue}}>✓</span>}</div>)}
        </div>}
        <div style={{height: 164, border: `1px solid ${C.line}`, borderRadius: 28, background: C.panel, padding: '22px 24px', boxSizing: 'border-box'}}>
          <div style={{fontSize: 24, color: typed ? C.text : '#858585', height: 48}}>{prompt || '向 Codex 提问，@ 添加上下文'}{typed && !sent && <span style={{borderRight: '2px solid white', marginLeft: 4, animation: 'blink 1s step-end infinite'}} />}</div>
          <div style={{display: 'flex', alignItems: 'center', gap: 13, fontSize: 22}}>
            <Icon>＋</Icon><span style={{fontWeight: 600}}>gpt 6 astra</span><span style={{fontSize: 16, color: C.blue}}>●</span><span style={{color: C.muted}}>⌄</span>
            <span style={{marginLeft: 14, borderLeft: `1px solid ${C.line}`, paddingLeft: 14, color: ultra ? C.text : C.muted}}>effort: {ultra ? 'ultra' : 'high'}</span>
            <span style={{marginLeft: 'auto', color: fast ? C.blue : C.muted, fontSize: 18}}>⚡ {fast ? '快速' : '标准'}</span>
            <span style={{fontSize: 25, color: C.muted}}>♩</span><span style={{borderRadius: 99, width: 46, height: 46, display: 'grid', placeItems: 'center', background: sent ? '#5b5b5b' : '#707070', fontSize: 24}}>↑</span>
          </div>
        </div>
        <div style={{display: 'flex', gap: 28, marginTop: 22, color: C.muted, fontSize: 21}}><span>▱ 本地⌄</span><span>♢ 默认权限⌄</span></div>
      </div>

      <div style={{position: 'absolute', left: 0, right: 0, bottom: 0, height: 405, borderTop: `1px solid ${C.line}`, padding: '34px 74px', boxSizing: 'border-box'}}>
        <div style={{fontSize: 23, color: C.muted, marginBottom: 42}}>◷ 使用限额</div>
        <Quota label="5h 限额" value={fiveHour} danger={fiveHour < 35} pulse={pulse} />
        <Quota label="7d 限额" value={sevenDay} pulse={pulse} />
      </div>
      {thinking && <div style={{position: 'absolute', top: 132, left: 0, right: 0, textAlign: 'center', color: C.muted, fontSize: 20, opacity: pulse}}>正在思考…</div>}
    </div>
    <style>{`@keyframes blink {50%{opacity:0}}`}</style>
  </AbsoluteFill>;
};

function Quota({label, value, danger, pulse}: {label: string; value: number; danger?: boolean; pulse: number}) {
  return <div style={{marginBottom: 58}}><div style={{display: 'flex', alignItems: 'baseline', justifyContent: 'space-between', marginBottom: 18}}><span style={{fontSize: 29, fontWeight: 600}}>{label}</span><span style={{fontSize: 21, color: C.muted}}>剩余 <strong style={{fontSize: 34, color: danger ? C.red : C.text}}>{Math.round(value)}%</strong></span></div><div style={{height: 15, borderRadius: 15, background: '#383838', overflow: 'hidden'}}><div style={{height: '100%', width: `${value}%`, borderRadius: 15, background: danger ? C.red : '#eeeeee', boxShadow: danger ? `0 0 18px ${C.red}${Math.round(pulse * 99).toString(16)}` : 'none'}} /></div></div>;
}
