# Project 01 — Codex Limits

Remotion vertical animation recreating the supplied Codex dark UI reference.

Timeline:

- 0.6s: model picker opens and selects `gpt 6 astra`
- 2.0s: effort becomes `ultra`
- 3.1s: fast mode turns on
- 2.2–5.1s: types `你好`; 5.1s: sends
- 5.6s onward: stays on `正在思考…`, no answer appears
- 5.8–16.5s: 5h drops to 0%, 7d drops to 85%, then holds

## Preview / render

```bash
npm install
npm run dev
npm run build
```

## ACE-Step music

Use this prompt in ACE-Step to generate the preview bed, then place the exported file at `public/ace-step-tension.mp3` and add it to the composition with Remotion's `<Audio>` component:

> tense minimal dark electronic underscore, slow pulse becoming urgent, granular synth ticks, low sub bass, restrained glitch texture, no vocals, 30 seconds, clean ending, cinematic UI suspense

The visual animation is intentionally independent of the audio so it can be previewed before the ACE-Step track is available.
